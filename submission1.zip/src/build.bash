#!/bin/bash
set -e -x
echo "Building..."

javac *.java

echo "To execute, do:"
echo "java Main"
echo “To execute with Neural Network, do:”
echo “java Main nn”
echo “The neural network takes a very long time to converge. I reduced the amount of time it runs a little, but the output is not as good now.”

